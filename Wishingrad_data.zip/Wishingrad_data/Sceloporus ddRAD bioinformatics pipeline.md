# Sceloporus ddRAD bioinformatics pipeline
### Adated from the [Rochette & Catchen 2017 pipeline ] (https://www.nature.com/articles/nprot.2017.123)
### Spring 2019
---




### Demultiplex reads

#### Part A: Demultiplex procedure
###### _note: barcode files are located in /info folder_

#### Process Radtags
```
#!/bin/bash
#SBATCH -J process_radtags
#SBATCH -n 40
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p lm.q
#SBATCH --mem-per-cpu 24000MB
#SBATCH -t 3-00:00
#SBATCH -o process_radtags.out
#SBATCH -e process_radtags.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/stacks/1.46
process_radtags -f ../raw/RTVW2018A_Idx_1_S9_L003_R1_001.fastq.gz -o ./ -b ../info/RTVW2018APool1.txt -r -c -D -q -t 95 --renz_1 sbfI --renz_2 nlaIII --retain_header  &> process_radtags_Idx_1.oe && \
process_radtags -f ../raw/RTVW2018A_Idx_2_S10_L003_R1_001.fastq.gz -o ./ -b ../info/RTVW2018APool2.txt -r -c -D -q -t 95 --renz_1 sbfI --renz_2 nlaIII --retain_header &> process_radtags_Idx_2.oe && \ 
process_radtags -f ../raw/RTVW2018A_Idx_3_S11_L003_R1_001.fastq.gz -o ./ -b ../info/RTVW2018APool3.txt -r -c -D -q -t 95 --renz_1 sbfI --renz_2 nlaIII --retain_header &> process_radtags_Idx_3.oe && \ 
process_radtags -f ../raw/RTVW2018A_Idx_4_S12_L003_R1_001.fastq.gz -o ./ -b ../info/RTVW2018APool4.txt -r -c -D -q -t 95 --renz_1 sbfI --renz_2 nlaIII --retain_header &> process_radtags_Idx_4.oe && \ 
process_radtags -f ../raw/RTVW2018A_Idx_5_S13_L003_R1_001.fastq.gz -o ./ -b ../info/RTVW2018APool5.txt -r -c -D -q -t 95 --renz_1 sbfI --renz_2 nlaIII --retain_header &> process_radtags_Idx_5.oe && \ 
process_radtags -f ../raw/RTVW2018A_Idx_6_S14_L003_R1_001.fastq.gz -o ./ -b ../info/RTVW2018APool6.txt -r -c -D -q -t 95 --renz_1 sbfI --renz_2 nlaIII --retain_header &> process_radtags_Idx_6.oe && \ 
process_radtags -f ../raw/RTVW2018A_Idx_7_S15_L003_R1_001.fastq.gz -o ./ -b ../info/RTVW2018APool7.txt -r -c -D -q -t 95 --renz_1 sbfI --renz_2 nlaIII --retain_header &> process_radtags_Idx_7.oe && \ 
process_radtags -f ../raw/RTVW2018A_Idx_8_S16_L003_R1_001.fastq.gz -o ./ -b ../info/RTVW2018APool8.txt -r -c -D -q -t 95 --renz_1 sbfI --renz_2 nlaIII --retain_header &> process_radtags_Idx_8.oe 

# -f: file dir
# -o: output dir
# -b: barcode dir
# -r: correct info and RE sites w/i certain distance from true barcode or RE cutsite
# -c: clean data, remove any read with an uncalled base.
# -D: capture discarded reads to a file.
# -q: discard reads with low quality scores.
# -t: truncate final read length to this value.
```
### Creation of a reference genome database (reference-based analysis only)

#### Create a BWA genome database:
##### Download the reference genome sequence of _Sceloporus occidentalis_. This is a FASTA (.fa) file that can be obtained from the sequence or genome databases. Place this file in the genome/ directory.

#### Create the BWA genome database
###### _note: run this script from the /genome directory_
```
#!/bin/bash
#SBATCH -J bwa_genome_db
#SBATCH -n 40
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p lm.q
#SBATCH --mem-per-cpu 24000MB
#SBATCH -t 3-00:00
#SBATCH -o bwa_genome_db.out
#SBATCH -e bwa_genome_db.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/bwa/0.7.15
bwa index -p bwa/socc socc.final.fasta &> bwa/bwa_index.oe
```

### Working on a subset of samples for parameter testing
#### Reference-based analysis

Choose a subset of a dozen representative samples, based on the read coverage numbers obtained above and the expected genetic similarities among samples (e.g., populations, if any). Write this list in a text file popmap_test_samples, formatted like popmap, and place this file in the info/ directory.

Choose a putatively appropriate alignment method. We start with BWA and default parameter values, but other short-read aligners or parameters are possible. Provided the reference genome is close to the considered data set, many parameter combinations will often yield equally good results, so testing alternative parameter combinations may not be necessary if the initial parameters lead to satisfactory results

##### For each sample of the subset, align the cleaned reads to the reference genome

```
sample=samplename
fq_file=../cleaned/$sample.fq.gz
bam_file=alignments.bwa/$sample.bam
bwa_db=../genome/bwa/socc
bwa mem -M $bwa_db $fq_file | samtools view -b > $bam_file
```
_note: samplename should be replaced with the name of each sample in the subset_

##### These files can be auto-generated using the following custom scripts:

###### Part A: Make empty files
```
#!/bin/bash

declare -a arr=("VW175" "VW084" "VW169" "CAS253021" "CAS227093" "VW141" "VW160" "VW227" "VW225" "MVZ251318" "CAS224897" "MVZ245622")

for i in "${arr[@]}"
do
	echo "$i.slurm" 
touch -- "$i.slurm"
done
```

###### Part B: Make SLURM files
_note: this is a python script_

```
###imported modules
import re
import sys
import os

###functions
#function for listing files in any path
def ls(path):
	files = os.listdir(path)
	#remove .DS Store files in the list of files in the folder
	if (files[0] == ".DS_Store"):
		files = files[1:] 
	return files

# function for calling shell commands within python script	
def shCall( cmd ):
	subprocess.call(cmd,shell=True)

def slurm_writer(file):
	base=os.path.splitext(os.path.basename(file))[0]
	slurm_writer=open(file, "a")
	slurm_writer.write("#!/bin/bash" +
		"\n" +
		"\n" + "#SBATCH -J " + base + ".align"
		"\n" + "#SBATCH -n 40" +
		"\n" + "#SBATCH -c 1" +
		"\n" + "#SBATCH -N 1" +
		"\n" + "#SBATCH -p lm.q" +
		"\n" + "#SBATCH --mem-per-cpu 24000MB" +
		"\n" + "#SBATCH -t 3-00:00" +
		"\n" + "#SBATCH -o " + base + ".align.out" +
		"\n" + "#SBATCH -e " + base + ".align.err" +
		"\n" + "#SBATCH --mail-type ALL" +
		"\n" + "#SBATCH --mail-user vanw@hawaii.edu" +
		"\n" + "source ~/.bash_profile" +
		"\n" + "module load bioinfo/bwa/0.7.15" +
		"\n" + "module load bioinfo/samtools/1.4.1" +
		"\n" +
		"\n" + "sample=" + base +
		"\n" + "fq_file=../cleaned/" + base + ".fq.gz" +
		"\n" + "bam_file=alignments.bwa/" + base + ".bam" +
		"\n" + "bwa_db=../genome/bwa/socc" +
		"\n" + "bwa mem -M $bwa_db $fq_file | samtools view -b > $bam_file")
	slurm_writer.close()

files = ls(".")
print (files)
for file in files:
		if file.startswith("VW"):
			slurm_writer(file)
		if file.startswith("CAS"):
			slurm_writer(file)
		if file.startswith("MVZ"):
			slurm_writer(file)
		if file.startswith("YPM"):
			slurm_writer(file)
```
###### Part C: Copy files to HPC and run all SLURM files

Copy files to the */tests.ref* directory, then run the following command...

```
for f in *.slurm; do sbatch $f; done
```  

...to execute all SLRUM files in the directory.

##### Move into the Stacks directory
Run the **pstacks** unit of Stacks on each sample of the subset. Provide a unique identifier for each sample. The following custrom scripts automate the process, assigning unique IDs for each sample based on sample catalog number (excluding museum/series alphanumerical code):

###### Part A: Make empty files
```
#!/bin/bash

declare -a arr=("VW175" "VW084" "VW169" "CAS253021" "CAS227093" "VW141" "VW160" "VW227" "VW225" "MVZ251318" "CAS224897" "MVZ245622")

for i in "${arr[@]}"
do
	echo "$i.slurm" 
touch -- "$i.slurm"
done
```
###### Part B: Make SLURM files
_note: this is a python script_

```
###imported modules
import re
import sys
import os

###functions
#function for listing files in any path
def ls(path):
	files = os.listdir(path)
	#remove .DS Store files in the list of files in the folder
	if (files[0] == ".DS_Store"):
		files = files[1:] 
	return files

# function for calling shell commands within python script	
def shCall( cmd ):
	subprocess.call(cmd,shell=True)

def slurm_writer(file):
	base=os.path.splitext(os.path.basename(file))[0]
	slurm_writer=open(file, "a")
	slurm_writer.write("#!/bin/bash" +
		"\n" +
		"\n" + "#SBATCH -J " + base + ".pstacks"
		"\n" + "#SBATCH -n 40" +
		"\n" + "#SBATCH -c 1" +
		"\n" + "#SBATCH -N 1" +
		"\n" + "#SBATCH -p lm.q" +
		"\n" + "#SBATCH --mem-per-cpu 24000MB" +
		"\n" + "#SBATCH -t 3-00:00" +
		"\n" + "#SBATCH -o " + "VW" + base + ".pstacks.out" +
		"\n" + "#SBATCH -e " + "VW" + base + ".pstacks.err" +
		"\n" + "#SBATCH --mail-type ALL" +
		"\n" + "#SBATCH --mail-user vanw@hawaii.edu" +
		"\n" + "source ~/.bash_profile" +
		"\n" + "module load bioinfo/stacks/1.46" +
		"\n" +
		"\n" + "sample=" + base +
		"\n" + "sample_index=" + base.translate({ord(i): None for i in 'VW MVZ CAS YPM'}) +
		"\n" + "bam_file=../" + base + ".bam" +
		"\n" + "log_file=" + base + ".pstacks.oe" +
		"\n" + "pstacks -f $bam_file -i $sample_index -o ./ &> $log_file")
	slurm_writer.close()

files = ls(".")
print (files)
for file in files:
		if file.startswith("VW"):
			slurm_writer(file)
		if file.startswith("CAS"):
			slurm_writer(file)
		if file.startswith("MVZ"):
			slurm_writer(file)
		if file.startswith("YPM"):
			slurm_writer(file)
```

Copy files to the /stacks.bwa directory, then run the following command...

```
for f in *.slurm; do sbatch $f; done
```  

...to execute all SLRUM files in the directory.

### Running the genotyping pipeline on the full data set
#### Reference-based analysis

After a set of parameters has been chosen, apply the pipeline to the full data set: for each sample, align the cleaned reads to the reference genome.


###### Part A: Make empty files

```
#!/bin/bash

declare -a arr=("CAS227121" "CAS224909" "CAS224107" "CAS227180" "CAS213189" "VW159" "CAS227622" "VW166" "VW083" "CAS220924" "VW175" "VW084" "VW169" "CAS253021" "CAS227093" "VW141" "VW160" "VW227" "VW225" "MVZ251318" "CAS224897" "MVZ245622" "VW222" "CAS224937" "VW090" "VW128" "VW236" "CAS220862" "VW153" "VW116" "VW228" "CAS227897" "CAS224108" "CAS220909" "VW149" "VW122" "VW080" "VW190" "CAS224099" "CAS224117" "CAS234569" "VW101" "VW242" "VW152" "CAS224917" "VW233" "CAS203418" "CAS225257" "CAS227116" "VW235" "CAS212854" "VW117" "MVZ245631" "CAS220923" "CAS225256" "VW172" "VW134" "VW148" "VW167" "VW165" "VW127" "CAS253016" "VW221" "CAS206501" "CAS224177" "CAS227458" "CAS219638" "CAS212818" "CAS227900" "CAS205821" "VW033" "CAS202857" "VW223" "VW037" "VW155" "VW158" "MVZ245630" "CAS219697" "VW185" "CAS208731" "CAS206289" "CAS212984" "CAS241780" "VW156" "CAS212963" "VW110" "VW219" "VW161" "VW131" "VW154" "CAS220888" "CAS206028" "CAS212274" "CAS227449" "CAS224893" "CAS224180" "MVZ245634" "VW179" "VW188" "CAS219661" "VW177" "VW041" "VW226" "CAS203103" "VW024" "VW106" "VW239" "VW170" "YPM017161" "VW147" "VW025" "CAS201580" "VW199" "CAS206265" "CAS226989" "CAS226788" "CAS205675" "CAS203430" "CAS220883" "CAS202885" "VW058" "CAS212863" "MVZ245707" "CAS213075" "CAS224167" "VW230" "CAS224891" "VW089" "CAS208838" "VW192" "CAS208844" "MVZ137818" "VW112" "CAS202915" "CAS224176" "CAS205877" "VW114" "CAS205365" "MVZ240987" "CAS213198" "VW103" "CAS212937" "CAS236205" "VW104" "VW306" "VW259" "VW231" "MVZ250152" "CAS206382" "CAS219619" "VW150" "CAS206091" "VW295" "VW038" "MVZ250125" "MVZ245627" "CAS224895" "VW138" "VW042" "VW034" "CAS224166" "CAS205683" "VW240" "VW079" "CAS201265" "CAS234574" "MVZ245666" "VW229" "CAS259612" "VW234" "VW241" "MVZ240911" "CAS227717" "CAS203451" "CAS213179" "MVZ250086" "MVZ241058" "VW115" "VW163" "VW243" "MVZ257302" "CAS226963" "VW050" "VW168" "CAS213086" "VW245" "VW246" "VW051" "VW054" "CAS219595" "VW244" "MVZ137819" "CAS205208" "VW247" "MVZ245626" "MVZ245638" "VW232" "VW040" "VW323" "MVZ240925" "MVZ137487" "VW201" "VW316" "VW039" "MVZ240929" "MVZ240985" "CAS205897" "CAS224887" "CAS202895" "CAS205867" "CAS224894" "VW139" "MVZ245635" "VW004" "VW081" "VW238" "VW061" "VW059" "VW056" "CAS224116" "VW015" "VW045" "CAS202910" "VW052" "CAS206060" "MVZ245633" "CAS205861" "CAS259640" "VW118" "MVZ245708" "VW032" "CAS203345" "CAS253014" "VW087" "VW047" "VW173" "CAS206179" "VW055" "CAS259921" "VW339" "CAS202854" "VW031" "VW046" "MVZ150076" "VW220" "CAS205200" "MVZ228762" "MVZ240984" "VW189" "VW326" "VW085" "CAS205899" "CAS212843" "YPM017146" "VW262" "VW113" "CAS205611" "VW105" "CAS206254" "CAS206107" "VW026" "YPM017142" "CAS224910" "MVZ245746" "VW060" "CAS205345" "VW044" "VW029" "VW133" "VW143" "YPM017514" "MVZ230092" "VW126" "MVZ257301" "CAS205568" "VW035" "VW119" "VW027" "VW048" "CAS205852" "VW076" "CAS259641" "VW107" "VW049" "VW088" "CAS208786" "CAS208887" "CAS202911" "MVZ250107" "CAS205219" "MVZ245629" "VW036" "MVZ245663" "CAS205871" "MVZ265555" "MVZ245734" "CAS205865" "VW028" "VW019" "CAS205874" "VW018" "VW328" "MVZ245784" "VW120" "MVZ245725" "VW283" "CAS201585" "MVZ240941" "VW013" "VW057" "VW021" "VW290" "MVZ250093" "MVZ245682" "MVZ245628" "CAS208920" "VW020" "MVZ245709" "CAS208912" "VW274" "MVZ233485" "CAS209321" "VW130" "MVZ245776" "CAS259638" "VW258" "MVZ244363" "VW324" "CAS212304" "VW078" "MVZ245618" "CAS209858" "CAS212966" "MVZ245636" "MVZ245658" "MVZ240981" "MVZ245773" "MVZ245723" "MVZ245623" "MVZ245665" "MVZ245710" "CAS236226" "VW261" "MVZ245639" "VW288" "VW318" "VW332" "VW017" "VW009" "CAS234558" "CAS234573" "VW186" "MVZ245659" "VW264" "VW010" "CAS259613" "CAS209881" "VW287" "CAS209432" "VW331" "CAS209849" "MVZ265557" "VW193" "CAS209239" "VW320" "MVZ233478" "VW136" "VW137" "CAS203486" "VW273" "CAS259670" "VW250" "VW142" "VW278" "CAS209274" "MVZ245664" "MVZ245681" "MVZ245657" "VW304" "CAS209970" "VW286" "VW053" "VW187" "VW279" "MVZ245625" "VW014" "VW305" "CAS224101" "VW319" "CAS206388" "VW302" "VW289" "VW252" "VW071" "MVZ245661" "MVZ245699" "VW265" "VW293" "VW284" "VW299" "MVZ240951" "CAS259933" "CAS209876" "VW336" "VW308" "VW275" "VW296" "CAS209714" "VW300" "CAS235795" "VW086" "CAS209363" "CAS209710" "MVZ245640" "MVZ245667" "VW314" "MVZ240909" "MVZ245662" "VW325" "VW001" "CAS208748" "VW215" "CAS259923" "MVZ233486" "VW307" "VW006" "VW140" "MVZ245660" "VW309" "VW008" "VW301" "MVZ245656" "MVZ240988" "MVZ250158" "VW285" "CAS205892" "CAS209961" "VW327" "VW256" "VW297" "VW069" "VW337" "MVZ241060" "MVZ257677" "VW291" "VW253" "MVZ250138" "VW016" "CAS209246" "CAS209957" "VW022" "VW077" "VW313" "VW070" "CAS209268" "VW294" "VW003" "VW311" "CAS209229" "VW322" "MVZ245637" "CAS203457" "MVZ245624" "MVZ250113" "CAS203421" "VW292" "VW315" "CAS209909" "VW002" "VW011" "VW298" "VW007" "VW005" "MVZ150075" "VW271" "VW012" "MVZ245632" "VW082" "MVZ233484" "CAS209972" "CAS209212" "CAS209857" "CAS209447")

for i in "${arr[@]}"
do
	echo "$i.slurm" 
touch -- "$i.slurm"
done
```
###### Part B: Make SLURM files. 
_note: this is a python script_

```
###imported modules
import re
import sys
import os

###functions
#function for listing files in any path
def ls(path):
	files = os.listdir(path)
	#remove .DS Store files in the list of files in the folder
	if (files[0] == ".DS_Store"):
		files = files[1:] 
	return files

# function for calling shell commands within python script	
def shCall( cmd ):
	subprocess.call(cmd,shell=True)

def slurm_writer(file):
	base=os.path.splitext(os.path.basename(file))[0]
	slurm_writer=open(file, "a")
	slurm_writer.write("#!/bin/bash" +
		"\n" +
		"\n" + "#SBATCH -J " + base + ".align"
		"\n" + "#SBATCH -n 8" +
		"\n" + "#SBATCH -c 1" +
		"\n" + "#SBATCH -N 1" +
		"\n" + "#SBATCH -p community.q" +
		"\n" + "#SBATCH --mem-per-cpu 6400MB" +
		"\n" + "#SBATCH -t 3-00:00" +
		"\n" + "#SBATCH -o " + base + ".align.out" +
		"\n" + "#SBATCH -e " + base + ".align.err" +
		"\n" + "#SBATCH --mail-type ALL" +
		"\n" + "#SBATCH --mail-user vanw@hawaii.edu" +
		"\n" + "source ~/.bash_profile" +
		"\n" + "module load bioinfo/bwa/0.7.15" +
		"\n" + "module load bioinfo/samtools/1.4.1" +
		"\n" +
		"\n" + "sample=" + base +
		"\n" + "fq_file=../cleaned/" + base + ".fq.gz" +
		"\n" + "bam_file=../alignments/" + base + ".bam" +
		"\n" + "bwa_db=../genome/bwa/socc" +
		"\n" + "bwa mem -M $bwa_db $fq_file | samtools view -b > $bam_file")
	slurm_writer.close()

files = ls(".")
print (files)
for file in files:
		if file.startswith("VW"):
			slurm_writer(file)
		if file.startswith("CAS"):
			slurm_writer(file)
		if file.startswith("MVZ"):
			slurm_writer(file)
		if file.startswith("YPM"):
			slurm_writer(file)
```
###### Part C: Copy files to HPC and run all SLURM files

Copy files to the /tests.ref directory, then run the following command...

```
for f in *.slurm; do sbatch $f; done
```  

...to execute all SLRUM files in the directory.

#### Create alignment files

Move into the Stacks directory */stacks.ref/stacks*

Run the **pstacks** unit of Stacks on each sample of the dataset. Provide a unique identifier for each sample. The following custrom scripts automate the process, assigning unique IDs for each sample based on sample catalog number (excluding museum/series alphanumerical code):

###### Part A: Make empty files
```
#!/bin/bash

declare -a arr=("CAS227121" "CAS224909" "CAS224107" "CAS227180" "CAS213189" "VW159" "CAS227622" "VW166" "VW083" "CAS220924" "VW175" "VW084" "VW169" "CAS253021" "CAS227093" "VW141" "VW160" "VW227" "VW225" "MVZ251318" "CAS224897" "MVZ245622" "VW222" "CAS224937" "VW090" "VW128" "VW236" "CAS220862" "VW153" "VW116" "VW228" "CAS227897" "CAS224108" "CAS220909" "VW149" "VW122" "VW080" "VW190" "CAS224099" "CAS224117" "CAS234569" "VW101" "VW242" "VW152" "CAS224917" "VW233" "CAS203418" "CAS225257" "CAS227116" "VW235" "CAS212854" "VW117" "MVZ245631" "CAS220923" "CAS225256" "VW172" "VW134" "VW148" "VW167" "VW165" "VW127" "CAS253016" "VW221" "CAS206501" "CAS224177" "CAS227458" "CAS219638" "CAS212818" "CAS227900" "CAS205821" "VW033" "CAS202857" "VW223" "VW037" "VW155" "VW158" "MVZ245630" "CAS219697" "VW185" "CAS208731" "CAS206289" "CAS212984" "CAS241780" "VW156" "CAS212963" "VW110" "VW219" "VW161" "VW131" "VW154" "CAS220888" "CAS206028" "CAS212274" "CAS227449" "CAS224893" "CAS224180" "MVZ245634" "VW179" "VW188" "CAS219661" "VW177" "VW041" "VW226" "CAS203103" "VW024" "VW106" "VW239" "VW170" "YPM017161" "VW147" "VW025" "CAS201580" "VW199" "CAS206265" "CAS226989" "CAS226788" "CAS205675" "CAS203430" "CAS220883" "CAS202885" "VW058" "CAS212863" "MVZ245707" "CAS213075" "CAS224167" "VW230" "CAS224891" "VW089" "CAS208838" "VW192" "CAS208844" "MVZ137818" "VW112" "CAS202915" "CAS224176" "CAS205877" "VW114" "CAS205365" "MVZ240987" "CAS213198" "VW103" "CAS212937" "CAS236205" "VW104" "VW306" "VW259" "VW231" "MVZ250152" "CAS206382" "CAS219619" "VW150" "CAS206091" "VW295" "VW038" "MVZ250125" "MVZ245627" "CAS224895" "VW138" "VW042" "VW034" "CAS224166" "CAS205683" "VW240" "VW079" "CAS201265" "CAS234574" "MVZ245666" "VW229" "CAS259612" "VW234" "VW241" "MVZ240911" "CAS227717" "CAS203451" "CAS213179" "MVZ250086" "MVZ241058" "VW115" "VW163" "VW243" "MVZ257302" "CAS226963" "VW050" "VW168" "CAS213086" "VW245" "VW246" "VW051" "VW054" "CAS219595" "VW244" "MVZ137819" "CAS205208" "VW247" "MVZ245626" "MVZ245638" "VW232" "VW040" "VW323" "MVZ240925" "MVZ137487" "VW201" "VW316" "VW039" "MVZ240929" "MVZ240985" "CAS205897" "CAS224887" "CAS202895" "CAS205867" "CAS224894" "VW139" "MVZ245635" "VW004" "VW081" "VW238" "VW061" "VW059" "VW056" "CAS224116" "VW015" "VW045" "CAS202910" "VW052" "CAS206060" "MVZ245633" "CAS205861" "CAS259640" "VW118" "MVZ245708" "VW032" "CAS203345" "CAS253014" "VW087" "VW047" "VW173" "CAS206179" "VW055" "CAS259921" "VW339" "CAS202854" "VW031" "VW046" "MVZ150076" "VW220" "CAS205200" "MVZ228762" "MVZ240984" "VW189" "VW326" "VW085" "CAS205899" "CAS212843" "YPM017146" "VW262" "VW113" "CAS205611" "VW105" "CAS206254" "CAS206107" "VW026" "YPM017142" "CAS224910" "MVZ245746" "VW060" "CAS205345" "VW044" "VW029" "VW133" "VW143" "YPM017514" "MVZ230092" "VW126" "MVZ257301" "CAS205568" "VW035" "VW119" "VW027" "VW048" "CAS205852" "VW076" "CAS259641" "VW107" "VW049" "VW088" "CAS208786" "CAS208887" "CAS202911" "MVZ250107" "CAS205219" "MVZ245629" "VW036" "MVZ245663" "CAS205871" "MVZ265555" "MVZ245734" "CAS205865" "VW028" "VW019" "CAS205874" "VW018" "VW328" "MVZ245784" "VW120" "MVZ245725" "VW283" "CAS201585" "MVZ240941" "VW013" "VW057" "VW021" "VW290" "MVZ250093" "MVZ245682" "MVZ245628" "CAS208920" "VW020" "MVZ245709" "CAS208912" "VW274" "MVZ233485" "CAS209321" "VW130" "MVZ245776" "CAS259638" "VW258" "MVZ244363" "VW324" "CAS212304" "VW078" "MVZ245618" "CAS209858" "CAS212966" "MVZ245636" "MVZ245658" "MVZ240981" "MVZ245773" "MVZ245723" "MVZ245623" "MVZ245665" "MVZ245710" "CAS236226" "VW261" "MVZ245639" "VW288" "VW318" "VW332" "VW017" "VW009" "CAS234558" "CAS234573" "VW186" "MVZ245659" "VW264" "VW010" "CAS259613" "CAS209881" "VW287" "CAS209432" "VW331" "CAS209849" "MVZ265557" "VW193" "CAS209239" "VW320" "MVZ233478" "VW136" "VW137" "CAS203486" "VW273" "CAS259670" "VW250" "VW142" "VW278" "CAS209274" "MVZ245664" "MVZ245681" "MVZ245657" "VW304" "CAS209970" "VW286" "VW053" "VW187" "VW279" "MVZ245625" "VW014" "VW305" "CAS224101" "VW319" "CAS206388" "VW302" "VW289" "VW252" "VW071" "MVZ245661" "MVZ245699" "VW265" "VW293" "VW284" "VW299" "MVZ240951" "CAS259933" "CAS209876" "VW336" "VW308" "VW275" "VW296" "CAS209714" "VW300" "CAS235795" "VW086" "CAS209363" "CAS209710" "MVZ245640" "MVZ245667" "VW314" "MVZ240909" "MVZ245662" "VW325" "VW001" "CAS208748" "VW215" "CAS259923" "MVZ233486" "VW307" "VW006" "VW140" "MVZ245660" "VW309" "VW008" "VW301" "MVZ245656" "MVZ240988" "MVZ250158" "VW285" "CAS205892" "CAS209961" "VW327" "VW256" "VW297" "VW069" "VW337" "MVZ241060" "MVZ257677" "VW291" "VW253" "MVZ250138" "VW016" "CAS209246" "CAS209957" "VW022" "VW077" "VW313" "VW070" "CAS209268" "VW294" "VW003" "VW311" "CAS209229" "VW322" "MVZ245637" "CAS203457" "MVZ245624" "MVZ250113" "CAS203421" "VW292" "VW315" "CAS209909" "VW002" "VW011" "VW298" "VW007" "VW005" "MVZ150075" "VW271" "VW012" "MVZ245632" "VW082" "MVZ233484" "CAS209972" "CAS209212" "CAS209857" "CAS209447")

for i in "${arr[@]}"
do
	echo "$i.slurm" 
touch -- "$i.slurm"
done
```
###### Part B: Make SLURM files
_note: this is a python script_

```
###imported modules
import re
import sys
import os

###functions
#function for listing files in any path
def ls(path):
	files = os.listdir(path)
	#remove .DS Store files in the list of files in the folder
	if (files[0] == ".DS_Store"):
		files = files[1:] 
	return files

# function for calling shell commands within python script	
def shCall( cmd ):
	subprocess.call(cmd,shell=True)

def slurm_writer(file):
	base=os.path.splitext(os.path.basename(file))[0]
	slurm_writer=open(file, "a")
	slurm_writer.write("#!/bin/bash" +
		"\n" +
		"\n" + "#SBATCH -J " + base + ".pstacks"
		"\n" + "#SBATCH -n 8" +
		"\n" + "#SBATCH -c 1" +
		"\n" + "#SBATCH -N 1" +
		"\n" + "#SBATCH -p community.q" +
		"\n" + "#SBATCH --mem-per-cpu 6400MB" +
		"\n" + "#SBATCH -t 3-00:00" +
		"\n" + "#SBATCH -o " + base + ".pstacks.out" +
		"\n" + "#SBATCH -e " + base + ".pstacks.err" +
		"\n" + "#SBATCH --mail-type ALL" +
		"\n" + "#SBATCH --mail-user vanw@hawaii.edu" +
		"\n" + "source ~/.bash_profile" +
		"\n" + "module load bioinfo/stacks/1.46" +
		"\n" +
		"\n" + "sample=" + base +
		"\n" + "sample_index=" + base.translate({ord(i): None for i in 'VW MVZ CAS YPM'}) +
		"\n" + "bam_file=../../alignments/" + base + ".bam" +
		"\n" + "log_file=" + base + ".pstacks.oe" +
		"\n" + "pstacks -f $bam_file -i $sample_index -o ./ &> $log_file")
	slurm_writer.close()

files = ls(".")
print (files)
for file in files:
		if file.startswith("VW"):
			slurm_writer(file)
		if file.startswith("CAS"):
			slurm_writer(file)
		if file.startswith("MVZ"):
			slurm_writer(file)
		if file.startswith("YPM"):
			slurm_writer(file)
```

Copy files to the /stacks directory, then run the following command...

```
for f in *.slurm; do sbatch $f; done
```  

...to execute all SLRUM files in the directory.

#### Create the catalog

Run the **cstacks** unit to create the catalog, specifying the --aligned option and the path to the list of samples from which to create the catalog. In the *stacks.ref/stacks* directory:

```
#!/bin/bash

#SBATCH -J cstacks.lm
#SBATCH -n 40
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p lm.q
#SBATCH --mem-per-cpu 24000MB
#SBATCH -t 3-00:00
#SBATCH -o cstacks.lm.out
#SBATCH -e cstacks.lm.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/stacks/1.46

cstacks --aligned -P ./ -M ../../info/popmap_catalog -p 40 &> cstacks.lm.oe

```
#### Match samples to the catalog

Run the **sstacks** unit on each sample separately to match the samples to the catalog:

```
#!/bin/bash

#SBATCH -J sstacks.kill
#SBATCH -n 20
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p kill.q
#SBATCH --mem-per-cpu 6400MB
#SBATCH -t 0-72:00
#SBATCH -o sstacks.kill.out
#SBATCH -e sstacks.kill.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/stacks/1.46

sstacks --aligned -P ./ -M ../../info/popmap_all --gapped -p 20 &> sstacks.kill.oe
```

#### Filtering inferred snps and haplotypes based on population-level data

Use the **rxstacks** unit to improve SNP genotype calls, to filter out unlikely haplotypic combinations, and to remove loci having high error rates. Run this program after the catalog has been created to obtain a population-wide view of the data set. For each individual sample, genotypes are partially recomputed, as the software now knows the alleles present at each site across the population. **rxstacks** uses this information to constrain the genotype caller, improving calls and providing new calls that were previously statistically insignificant. Loci that are found to be confounded in multiple samples (i.e., possessing low locus likelihoods) are filtered out along with unlikely haplotypes resulting from error. The **rxstacks** unit rewrites the files for each sample, and afterward we will create a new catalog, excluding the identified, troublesome loci and including the improved genotype calls.

Start this part by creating a new subdirectory */rxstacks* under the *stacks.ref/stacks* directory and moving into this directory.

Execute the **rxstacks** unit. In addition to improving SNP calls, we choose to remove unlikely haplotypes:

```
#!/bin/bash

#SBATCH -J rxstacks.kill
#SBATCH -n 20
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p kill.q
#SBATCH --mem-per-cpu 6400MB
#SBATCH -t 0-72:00
#SBATCH -o rxstacks.kill.out
#SBATCH -e rxstacks.kill.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/stacks/1.46

rxstacks -P ../ -o ./ -t 20 --prune_haplo &> rxstacks.kill.oe

# P — path to the Stacks output files.
# o — output path to write results.
# t — number of threads to run in parallel sections of code.
# --prune_haplo — prune out non-biological haplotypes unlikely to occur in the population.
```

For each sample, rxstacks will write the same files as pstacks and ustacks in the new subdirectory.

#### Make corrections to genotype and haplotype calls in individual samples based on data accumulated from a population-wide examination.

Run the **cstacks** and **sstacks** units again, this time in the *rxstacks/* subdirectory, using the same commands as above, with modified paths to the catalog files.

**cstacks** script:

```
#!/bin/bash

#SBATCH -J rx.cstacks.kill
#SBATCH -n 20
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p kill.q
#SBATCH --mem-per-cpu 6400MB
#SBATCH -t 0-72:00
#SBATCH -o rx.cstacks.kill.out
#SBATCH -e rx.cstacks.kill.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/stacks/1.46

cstacks --aligned -P ./ -M ../../../info/popmap_catalog -p 20 &> rx.cstacks.kill.oe
```

**sstacks** script:

```
#!/bin/bash

#SBATCH -J rx.sstacks.kill
#SBATCH -n 20
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p kill.q
#SBATCH --mem-per-cpu 6400MB
#SBATCH -t 0-72:00
#SBATCH -o rx.sstacks.kill.out
#SBATCH -e rx.sstacks.kill.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/stacks/1.46

sstacks --aligned -P ./ -M ../../../info/popmap_all --gapped -p 20 &> rx.sstacks.kill.oe
```

#### Filtering genotypes and exporting the data

Run the **populations** program.

```
#!/bin/bash

#SBATCH -J populations2_1pop25.kill
#SBATCH -n 8
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p kill.q
#SBATCH --mem-per-cpu 6400MB
#SBATCH -t 3-00:00
#SBATCH -o populations2_1pop25.kill.out
#SBATCH -e populations2_1pop25.kill.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/stacks/1.46

popmap=../../../info/popmap_1pop
out_dir=populations2_1pop25.kill
log_file=populations2_1pop25.kill.oe
populations -P ./ -M $popmap -O $out_dir -t 8 -p 1 -r 0.25 --write_single_snp --fstats --fst_correction p_value --p_value_cutoff 0.05 --kernel_smoothed --bootstrap_fst --ordered_export --fasta_strict --vcf --structure --verbose &> populations2_1pop25.kill.oe
```

Available options:

```
populations 1.46
Usage:
populations -P dir [-O dir] [-M popmap] (filters) [--fstats] [-k [--sigma=150000] [--bootstrap [-N 100]]] (output formats)
populations -V vcf -O dir [-M popmap] (filters) [--fstats] [-k [--sigma=150000] [--bootstrap [-N 100]]] (output formats)

  -P,--in_path: path to the directory containing the Stacks files.
  -V,--in_vcf: path to an input VCF file.
  -O,--out_path: path to a directory where to write the output files. (Required by -V; otherwise defaults to value of -P.)
  -M,--popmap: path to a population map. (Format is 'SAMPLE1 \t POP1 \n SAMPLE2 ...'.)
  -t,--threads: number of threads to run in parallel sections of code.
  -b,--batch_id: ID of the catalog to consider (default: guess).
  -s,--sql_out: output a file to import results into an SQL database.

Data Filtering:
  -p [int]: minimum number of populations a locus must be present in to process a locus.
  -r [float]: minimum percentage of individuals in a population required to process a locus for that population.
  --min_maf [float]: specify a minimum minor allele frequency required to process a nucleotide site at a locus (0 < min_maf < 0.5).
  --max_obs_het [float]: specify a maximum observed heterozygosity required to process a nucleotide site at a locus.
  -m [int]: specify a minimum stack depth required for individuals at a locus.
  --lnl_lim [float]: filter loci with log likelihood values below this threshold.
  --write_single_snp: restrict data analysis to only the first SNP per locus.
  --write_random_snp: restrict data analysis to one random SNP per locus.
  -B: path to a file containing Blacklisted markers to be excluded from the export.
  -W: path to a file containing Whitelisted markers to include in the export.

Merging and Phasing:
  -e,--renz: restriction enzyme name.
  --merge_sites: merge loci that were produced from the same restriction enzyme cutsite (requires reference-aligned data).
  --merge_prune_lim: when merging adjacent loci, if at least X% samples posses both loci prune the remaining samples out of the analysis.

Fstats:
  --fstats: enable SNP and haplotype-based F statistics.
  --fst_correction: specify a correction to be applied to Fst values: 'p_value', 'bonferroni_win', or 'bonferroni_gen'. Default: off.
  --p_value_cutoff [float]: maximum p-value to keep an Fst measurement. Default: 0.05. (Also used as base for Bonferroni correction.)

Kernel-smoothing algorithm:
  -k,--kernel_smoothed: enable kernel-smoothed Pi, Fis, Fst, Fst', and Phi_st calculations.
  --sigma [int]: standard deviation of the kernel smoothing weight distribution. Default 150kb.
  --bootstrap: turn on boostrap resampling for all smoothed statistics.
  -N,--bootstrap_reps [int]: number of bootstrap resamplings to calculate (default 100).
  --bootstrap_pifis: turn on boostrap resampling for smoothed SNP-based Pi and Fis calculations.
  --bootstrap_fst: turn on boostrap resampling for smoothed Fst calculations based on pairwise population comparison of SNPs.
  --bootstrap_div: turn on boostrap resampling for smoothed haplotype diveristy and gene diversity calculations based on haplotypes.
  --bootstrap_phist: turn on boostrap resampling for smoothed Phi_st calculations based on haplotypes.
  --bootstrap_wl [path]: only bootstrap loci contained in this whitelist.

File output options:
  --ordered_export: if data is reference aligned, exports will be ordered; only a single representative of each overlapping site.
  --genomic: output each nucleotide position (fixed or polymorphic) in all population members to a file (requires --renz).
  --fasta: output full sequence for each unique haplotype, from each sample locus in FASTA format, regardless of plausibility.
  --fasta_strict: output full sequence for each haplotype, from each sample locus in FASTA format, only for biologically plausible loci.
  --vcf: output SNPs in Variant Call Format (VCF).
  --vcf_haplotypes: output haplotypes in Variant Call Format (VCF).
  --genepop: output results in GenePop format.
  --structure: output results in Structure format.
  --phase: output genotypes in PHASE format.
  --fastphase: output genotypes in fastPHASE format.
  --beagle: output genotypes in Beagle format.
  --beagle_phased: output haplotypes in Beagle format.
  --plink: output genotypes in PLINK format.
  --hzar: output genotypes in Hybrid Zone Analysis using R (HZAR) format.
  --phylip: output nucleotides that are fixed-within, and variant among populations in Phylip format for phylogenetic tree construction.
  --phylip_var: include variable sites in the phylip output encoded using IUPAC notation.
  --phylip_var_all: include all sequence as well as variable sites in the phylip output encoded using IUPAC notation.
  --treemix: output SNPs in a format useable for the TreeMix program (Pickrell and Pritchard).

Additional options:
  -h,--help: display this help messsage.
  -v,--version: print program version.
  --verbose: turn on additional logging.
  --log_fst_comp: log components of Fst/Phi_st calculations to a file.
```

#### Run VCF tools to remove lizards with low coverage and increase number of SNPs sampled across individuals

```
 vcftools --vcf batch_1.vcf --out missing.ind --missing-indv
```
Re-run the **populations** with identical parameters to generate a final dataset which excludes samples with low coverage.

```
#!/bin/bash

#SBATCH -J populations2_1pop25_10kSNPs.kill
#SBATCH -n 8
#SBATCH -c 1
#SBATCH -N 1
#SBATCH -p kill.q
#SBATCH --mem-per-cpu 6400MB
#SBATCH -t 3-00:00
#SBATCH -o populations2_1pop25_10kSNPs.kill.out
#SBATCH -e populations2_1pop25_10kSNPs.kill.err
#SBATCH --mail-type ALL
#SBATCH --mail-user vanw@hawaii.edu
source ~/.bash_profile
module load bioinfo/stacks/1.46

popmap=../../../info/popmap_1pop10kSNPs
out_dir=populations2_1pop25_10kSNPs.kill
log_file=populations2_1pop25_10kSNPs.kill.oe
populations -P ./ -M $popmap -O $out_dir -t 8 -p 1 -r 0.25 --write_single_snp --fstats --fst_correction p_value --p_value_cutoff 0.05 --kernel_smoothed --bootstrap_fst --ordered_export --fasta_strict --vcf --structure --verbose &> populations2_1pop25_10kSNPs.kill.oe
```

This will produce several output files for downstream analysis.

#end