# MMRR

# set working directory
setwd("~/")

# clim overlap
clim.matrix <- read.csv("clim.matrix.csv")
# remove first row
clim.matrix <- clim.matrix[ -c(1) ]
# remove column names
colnames(clim.matrix) <- NULL
# write to file
write.table(clim.matrix, file = "clim.matrix.txt", sep ="\t", row.names =F)

library(dplyr)
lt <- lower.tri(clim.matrix)
ut <- upper.tri(clim.matrix)

library(gdata)
clim.matrix[lt] <- ifelse(is.na(lowerTriangle(clim.matrix, byrow=FALSE)), upperTriangle(clim.matrix, byrow=TRUE), lowerTriangle(clim.matrix, byrow=FALSE))
upperTriangle(clim.matrix) <- lowerTriangle(clim.matrix, byrow=TRUE)

write.table(clim.matrix, file = "clim.dist.txt", sep ="\t", row.names =F)
as.matrix(clim.matrix)

# geo dist
geo.dist <- read.csv("dist.diff.mat.csv")
#View(geo.dist)
# remove column names
colnames(geo.dist) <- NULL
as.matrix(geo.dist)
write.table(geo.dist, file = "geo.dist.txt", sep ="\t", row.names =F)

# genetic distances
gen.dist <-read.csv("distgenDISS.csv")
# View(gen.dist)
# remove column names
colnames(gen.dist) <- NULL
as.matrix(gen.dist)
write.table(gen.dist, file = "gen.dist.txt", sep ="\t", row.names =F)

### Wang method ###

# MMRR performs Multiple Matrix Regression with Randomization analysis
# Y is a dependent distance matrix
# X is a list of independent distance matrices (with optional names)

Y=gen.dist
X=c(clim.matrix,geo.dist,elev.diff.mat)

MMRR<-function(Y,X,nperm=999){
  #compute regression coefficients and test statistics
  nrowsY<-nrow(Y)
  y<-unfold(Y)
  if(is.null(names(X)))names(X)<-paste("X",1:length(X),sep="")
  Xmats<-sapply(X,unfold)
  fit<-lm(y~Xmats)
  coeffs<-fit$coefficients
  summ<-summary(fit)
  r.squared<-summ$r.squared
  tstat<-summ$coefficients[,"t value"]
  Fstat<-summ$fstatistic[1]
  tprob<-rep(1,length(tstat))
  Fprob<-1
  
  #perform permutations
  for(i in 1:nperm){
    rand<-sample(1:nrowsY)
    Yperm<-Y[rand,rand]
    yperm<-unfold(Yperm)
    fit<-lm(yperm~Xmats)
    summ<-summary(fit)
    Fprob<-Fprob+as.numeric(summ$fstatistic[1]>=Fstat)
    tprob<-tprob+as.numeric(abs(summ$coefficients[,"t value"])>=abs(tstat))
  }
  
  #return values
  tp<-tprob/(nperm+1)
  Fp<-Fprob/(nperm+1)
  names(r.squared)<-"r.squared"
  names(coeffs)<-c("Intercept",names(X))
  names(tstat)<-paste(c("Intercept",names(X)),"(t)",sep="")
  names(tp)<-paste(c("Intercept",names(X)),"(p)",sep="")
  names(Fstat)<-"F-statistic"
  names(Fp)<-"F p-value"
  return(list(r.squared=r.squared,
              coefficients=coeffs,
              tstatistic=tstat,
              tpvalue=tp,
              Fstatistic=Fstat,
              Fpvalue=Fp))
}

# unfold converts the lower diagonal elements of a matrix into a vector
# unfold is called by MMRR

unfold<-function(X){
  x<-vector()
  for(i in 2:nrow(X)) x<-c(x,X[i,1:i-1])
  return(x)
}


# Run MMRR
# load matrices
library(tseries)

# rename matrices
genMat <- read.matrix("gen.dist.txt")
geoMat = read.matrix("geo.dist.txt")
climMat = read.matrix("clim.dist.txt")

Xmats <- list(climate=climMat,geography=geoMat)

MMRR(genMat,Xmats,nperm=999)

#$r.squared
#r.squared 
#0.4125355 

#$coefficients
#Intercept       climate     geography 
#3.568281e-02 -1.721756e-04  3.573404e-05 

#$tstatistic
#Intercept(t)   climate(t) geography(t) 
#102.68194     -4.99150     72.46824 

#$tpvalue
#Intercept(p)   climate(p) geography(p) 
#0.004        0.044        0.001 

#$Fstatistic
#F-statistic 
#2626.342 

#$Fpvalue
#F p-value 
#0.001 

# matrix correlations 
# remove lower triangle to avoid replication

climMat[lower.tri(climMat)] <- NA
genMat[lower.tri(genMat)] <- NA
geoMat[lower.tri(geoMat)] <- NA

climVec = c(climMat)
genVec = c(genMat)
geoVec = c(geoMat)

# should show IBD
par(mfrow=c(1,2))
par(mar=c(5,5,4,5))
plot(geoVec, genVec)
cor.test(geoVec, genVec)

# VERIFIED #

# plots with labels
# IBD
par(mfrow=c(1,2))
plot(climVec, genVec,
     ylab = "Allelic differentiation",
     xlab = "Climate overlap value")
plot(geoVec, genVec,
     ylab = "Allelic differentiation",
     xlab = "Geographic distance (km)")
